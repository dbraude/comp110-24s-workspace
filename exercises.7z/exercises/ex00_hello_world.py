"""My first program for COMP110."""

__author__ = "730704898"


print("Hello, world.")